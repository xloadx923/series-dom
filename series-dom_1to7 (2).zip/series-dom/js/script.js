
// 1/ Récupérer les données en javascript sur les séries présentes dans le fichier datas/series.json.
let series;
try {
    fetch ("datas/series.json")
    .then(response => response.json())
    .then(json =>{
        series = json;
        displaySeries(json);
        displayStyles(getStyles(json));
        console.log(getIdFromStyle("Western"));
        underlineStyle();
    }); 
} catch (error) {
    console.error("error" + error);
}

// 2/ Créer une fonction pour afficher toutes les séries dans la page avec pour chacune son titre et son image.
function displaySeries() {
    const element = document.getElementById("container");
    for(const serie of series) {
        element.innerHTML += `<li><h2>${serie.name}</h2><img class="image" src="${serie.image}"> </li>`;
    }

    // document.getElementById("container").innerHTML = series.map(serie => `<li><h2>${serie.name}</h2><img class="image" src="${serie.image}"> </li>`).join("")
}

// 3/ Créer une fonction qui retourne la liste des styles de séries présents dans les données.

function getStyles() {
    const array = []
    series.forEach(serie => {
        serie.styles.forEach(style => {
            if(!array.includes(style)) {
                array.push(style)
            }
        }) 
    });
    return array;
}



// 4/ Créer une fonction qui affiche la liste des styles de séries.
function displayStyles(styles){
    styles.forEach(style =>{
        document.getElementById("styles").innerHTML+=`<li>${style} (${countSeriesFromStyle(style)}) </li>`
    })

    // document.getElementById("styles").innerHTML = styles.map(style => `<li>${style}</li>`).join("")
}

// 5/ Créer une fonction qui compte le nombre de séries d'un style.

function countSeriesFromStyle(style){
    let nbrSeries = 0;
    series.forEach(serie => {
        if(serie.styles.includes(style)){
            nbrSeries++;
        }
    });
    return nbrSeries;

    // return series.filter(serie => serie.styles.includes(style)).length;
}

// 6/ Affichez dans la liste des styles le nombre de séries correspondantes entre parenthèse.
//      Modifier la fonction de la question 4/


// 7/ Créer une fonction qui retourne les ID des séries d'un style.

function getIdFromStyle(style){
    return series.filter(serie => serie.styles.includes(style)).map(serie => serie.id);
}

// 8/ Créer une fonction qui gère les clics sur les styles afin de les souligner lorsqu'ils sont cliqués.

function underlineStyle(){
    document.querySelectorAll("#styles > li").forEach(li =>{
        li.addEventListener("click", function(event){
            console.log(this);    
        })
    });
}

// 9/ Créer une fonction pour retirer le soulignement de tous les styles.
//      Utiliser cette fonction pour qu'à la question 8/ seul le dernier style cliqué soit souligné.


// 10/ Créer une fonction qui affiche dans la page uniquement les séries dont l'id est en paramètre.


// 11/ Modifier la fonction de la question 8/ afin de filtrer les séries au clic sur un style.








// 12/ Créer une fonction qui retourne toutes les données d'une série à partir de son ID


// 13/ Créer une fonction qui permet d'afficher l'id d'une série dans la console lorsque l'on clique dessus.


// 14/ Modifier la fonction ci-dessus pour retourner toutes les infos de la serie cliquée dans la console.


// 15/ Créer une fonction permettant d'ajouter une série à une liste de favoris.
// Une série ne peut être présente qu'une fois dans le tableau.


// 16/ Créer une fonction pour ajouter une série en favoris au click.


// 17/ Créer une fonction qui affiche le nom des séries favorites dans la page


// 18/ Créer une fonction permettant de retirer une série de la liste des favoris de par son id.


// 19/ Créez une fonction qui fasse qu'au clic sur un favoris il se retire de la liste.


// 20/ Créer une fonction qui affiche le nombre de favoris en titre de la liste des favoris.


// 21/ Créer une fonction qui retourne les id des séries par ordre d'année de sortie.


// 22/ Créer une fonction qui affiche les séries dans la page dans l'ordre des ids passés en paramètre.


// 23/ Créer une fonction qui permet de gérer au clic sur un lien dans la page le tri des series par années croissantes


// 24/ Permettez à la fonction précédente de gérer un click sur un autre lien pour trier les series par années décroissantes.